#!/bin/bash

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE DATABASE peace_music;"
sudo -u postgres psql -c "CREATE USER peace_user WITH ENCRYPTED PASSWORD 'your_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE peace_music TO peace_user;"

# Install Redis
sudo apt-get install -y redis-server

# Start Redis service
sudo systemctl start redis-server
sudo systemctl enable redis-server

# Create uploads directory
mkdir -p uploads
chmod 755 uploads

# Install PM2 globally
sudo npm install -g pm2

# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate deploy

# Start the application with PM2
pm2 start dist/index.js --name "peace-music"

# Save PM2 process list
pm2 save

# Setup PM2 to start on system boot
pm2 startup 