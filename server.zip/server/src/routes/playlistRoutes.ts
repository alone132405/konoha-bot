import { Router } from 'express';
import {
  createPlaylist,
  getPlaylist,
  updatePlaylist,
  deletePlaylist,
  addSongToPlaylist,
  removeSongFromPlaylist
} from '../controllers/playlistController';
import { auth } from '../middleware/auth';

const router = Router();

// Public routes
router.get('/:id', getPlaylist);

// Protected routes
router.post('/', auth, createPlaylist);
router.put('/:id', auth, updatePlaylist);
router.delete('/:id', auth, deletePlaylist);
router.post('/:playlistId/songs/:songId', auth, addSongToPlaylist);
router.delete('/:playlistId/songs/:songId', auth, removeSongFromPlaylist);

export default router; 