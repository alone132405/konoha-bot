import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import { uploadSong, getSong, streamSong, deleteSong } from '../controllers/songController';
import { auth } from '../middleware/auth';

const router = Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../../uploads'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.mp3', '.wav', '.ogg'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only MP3, WAV, and OGG files are allowed.'));
    }
  }
});

// Public routes
router.get('/:id', getSong);
router.get('/:id/stream', streamSong);

// Protected routes
router.post('/upload', auth, upload.single('song'), uploadSong);
router.delete('/:id', auth, deleteSong);

export default router; 