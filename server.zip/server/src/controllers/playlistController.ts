import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const createPlaylist = async (req: Request, res: Response) => {
  try {
    const { name, description, isPublic } = req.body;
    const userId = (req as any).user.id;

    const playlist = await prisma.playlist.create({
      data: {
        name,
        description,
        isPublic: isPublic ?? true,
        userId
      }
    });

    res.status(201).json(playlist);
  } catch (error) {
    console.error('Create playlist error:', error);
    res.status(500).json({ message: 'Error creating playlist' });
  }
};

export const getPlaylist = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const playlist = await prisma.playlist.findUnique({
      where: { id },
      include: {
        songs: {
          include: {
            uploadedBy: {
              select: {
                id: true,
                username: true,
                avatar: true
              }
            }
          }
        },
        createdBy: {
          select: {
            id: true,
            username: true,
            avatar: true
          }
        }
      }
    });

    if (!playlist) {
      return res.status(404).json({ message: 'Playlist not found' });
    }

    if (!playlist.isPublic && playlist.userId !== (req as any).user?.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    res.json(playlist);
  } catch (error) {
    console.error('Get playlist error:', error);
    res.status(500).json({ message: 'Error fetching playlist' });
  }
};

export const updatePlaylist = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { name, description, isPublic } = req.body;
    const userId = (req as any).user.id;

    const playlist = await prisma.playlist.findUnique({
      where: { id }
    });

    if (!playlist) {
      return res.status(404).json({ message: 'Playlist not found' });
    }

    if (playlist.userId !== userId) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedPlaylist = await prisma.playlist.update({
      where: { id },
      data: {
        name,
        description,
        isPublic
      }
    });

    res.json(updatedPlaylist);
  } catch (error) {
    console.error('Update playlist error:', error);
    res.status(500).json({ message: 'Error updating playlist' });
  }
};

export const deletePlaylist = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user.id;

    const playlist = await prisma.playlist.findUnique({
      where: { id }
    });

    if (!playlist) {
      return res.status(404).json({ message: 'Playlist not found' });
    }

    if (playlist.userId !== userId) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    await prisma.playlist.delete({
      where: { id }
    });

    res.json({ message: 'Playlist deleted successfully' });
  } catch (error) {
    console.error('Delete playlist error:', error);
    res.status(500).json({ message: 'Error deleting playlist' });
  }
};

export const addSongToPlaylist = async (req: Request, res: Response) => {
  try {
    const { playlistId, songId } = req.params;
    const userId = (req as any).user.id;

    const playlist = await prisma.playlist.findUnique({
      where: { id: playlistId }
    });

    if (!playlist) {
      return res.status(404).json({ message: 'Playlist not found' });
    }

    if (playlist.userId !== userId) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const song = await prisma.song.findUnique({
      where: { id: songId }
    });

    if (!song) {
      return res.status(404).json({ message: 'Song not found' });
    }

    await prisma.playlist.update({
      where: { id: playlistId },
      data: {
        songs: {
          connect: { id: songId }
        }
      }
    });

    res.json({ message: 'Song added to playlist successfully' });
  } catch (error) {
    console.error('Add song to playlist error:', error);
    res.status(500).json({ message: 'Error adding song to playlist' });
  }
};

export const removeSongFromPlaylist = async (req: Request, res: Response) => {
  try {
    const { playlistId, songId } = req.params;
    const userId = (req as any).user.id;

    const playlist = await prisma.playlist.findUnique({
      where: { id: playlistId }
    });

    if (!playlist) {
      return res.status(404).json({ message: 'Playlist not found' });
    }

    if (playlist.userId !== userId) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    await prisma.playlist.update({
      where: { id: playlistId },
      data: {
        songs: {
          disconnect: { id: songId }
        }
      }
    });

    res.json({ message: 'Song removed from playlist successfully' });
  } catch (error) {
    console.error('Remove song from playlist error:', error);
    res.status(500).json({ message: 'Error removing song from playlist' });
  }
}; 