# Install Chocolatey (Windows package manager)
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))

# Install Node.js
choco install nodejs -y

# Install PostgreSQL
choco install postgresql -y

# Install Redis
choco install redis-64 -y

# Create uploads directory
New-Item -ItemType Directory -Force -Path "uploads"

# Install PM2 globally
npm install -g pm2

# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate deploy

# Start Redis service
Start-Service Redis

# Start PostgreSQL service
Start-Service postgresql

# Create database and user
$env:Path += ";C:\Program Files\PostgreSQL\14\bin"
psql -U postgres -c "CREATE DATABASE peace_music;"
psql -U postgres -c "CREATE USER peace_user WITH ENCRYPTED PASSWORD 'your_password';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE peace_music TO peace_user;"

# Start the application with PM2
pm2 start dist/index.js --name "peace-music"

# Save PM2 process list
pm2 save

# Setup PM2 to start on system boot
pm2 startup 